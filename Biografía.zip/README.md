# Biografía Personal - Marcos Sous Chef Jr

Este es un proyecto personal sencillo creado como parte de una práctica de Git y GitHub.  
Incluye una biografía básica en HTML y CSS con un diseño limpio y profesional.

## Tecnologías utilizadas

- HTML5
- CSS3

## Autor

Marcos Sous Chef Jr – Estudiante de Ingeniería en Ciberseguridad y Sous Chef profesional.